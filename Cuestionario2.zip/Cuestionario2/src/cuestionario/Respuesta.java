/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cuestionario;

import java.util.ArrayList;

/**
 *
 * @author Pedro
 */
public class Respuesta {

    
    private Integer NumeroPregunta;
    private Integer NumeroRespuesta;
    private ArrayList<String> RespuestasElegidas;
        
    public Integer getNumeroPregunta() {
        return NumeroPregunta;
    }

    public void setNumeroPregunta(Integer NumeroPregunta) {
        this.NumeroPregunta = NumeroPregunta;
    }
    
    public Integer getNumeroRespuesta() {
        return NumeroRespuesta;
    }

    public ArrayList<String> getRespuestasElegidas() {
        return RespuestasElegidas;
    }

    public void setNumeroRespuesta(Integer iNumberQuestion) {
        this.NumeroRespuesta = iNumberQuestion;
    }

    public void setRespuestasElegidas(ArrayList<String> strResponsesChosen) {
        this.RespuestasElegidas = strResponsesChosen;
    }
     
    public ArrayList<String> getRespuestasElegidas(Integer iNumeroPregunta) {
        
        ArrayList<String> aliResultado = new ArrayList<>();
        
        if (iNumeroPregunta.equals(NumeroRespuesta)){
            aliResultado = RespuestasElegidas;
        } else {
            aliResultado = null;
        }    
        return aliResultado;
        
    } 
    
}
