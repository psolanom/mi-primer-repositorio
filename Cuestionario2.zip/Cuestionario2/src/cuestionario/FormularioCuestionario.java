/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cuestionario;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import static cuestionario.PantallaPrincipal.accBD;
import static cuestionario.PantallaPrincipal.conBD;
import static cuestionario.Resultados.txtResPreguntasContestadas;
import static cuestionario.Resultados.txtResPreguntasCorrectas;
import static cuestionario.Resultados.txtResPreguntasLeidas;
import static cuestionario.Resultados.txtResPreguntasTotales;
import static java.awt.event.KeyEvent.VK_A;
import static java.awt.event.KeyEvent.VK_B;
import static java.awt.event.KeyEvent.VK_C;
import static java.awt.event.KeyEvent.VK_D;
import static java.awt.event.KeyEvent.VK_E;
import static java.awt.event.KeyEvent.VK_F;
import static java.awt.event.KeyEvent.VK_G;
import static java.awt.event.KeyEvent.VK_H;
import static java.awt.event.KeyEvent.VK_I;
import static java.awt.event.KeyEvent.VK_J;
import static java.awt.event.KeyEvent.VK_K;
import static java.awt.event.KeyEvent.VK_LEFT;
import static java.awt.event.KeyEvent.VK_RIGHT;
import java.util.Iterator;
import static cuestionario.Resultados.txtResTantoPorCientoContestadas;

/**
 *
 * @author p.solano
 *
 */

public class FormularioCuestionario extends javax.swing.JInternalFrame {
    
    Integer                 iNumeroPreguntaActual;
        
    Object[][]              objPregunta;
    Object[][]              objOpcionesRespuesta;
    
    Integer                 iNumeroPrimeraPregunta;
    Integer                 iNumeroUltimaPregunta;
    
    //Lista
    ArrayList<Pregunta>     arlPreguntas;
    ArrayList<Respuesta>    arlRespuestas;
    
    Iterator<Pregunta>      iterator;
    
    public FormularioCuestionario() throws InstantiationException, IllegalAccessException, SQLException {
        
        initComponents();
        
        //Inicializamos el número de pregunta actual
        iNumeroPreguntaActual = 0;        
        
        //Obtenemos las preguntas y las guardamos en el objeto Pregunta
        objPregunta = accBD.obtenerPreguntas(conBD);
        
        //Inicializamos los valores del número de la primera pregunta y del número de la última pregunta
        iNumeroPrimeraPregunta = 1;
        iNumeroUltimaPregunta = objPregunta.length;        
        
        //Si existen preguntas
        if ( objPregunta != null ){
            
            //Instanciamos la lista de respuestas
            arlPreguntas = new ArrayList<>();
            
            cargarListaDePreguntas(objPregunta);
            
            iterator = arlPreguntas.iterator();
            
            //Cargamos los datos de las preguntas
            cargarDatosPreguntaEnPantalla(iNumeroPreguntaActual, objPregunta);
            
            //Instanciamos la lista de respuestas
            arlRespuestas = new ArrayList<>();
            
            btnSiguiente.setEnabled(true);
            btnAnterior.setEnabled(false);
                        
            this.setFocusable(true);
            this.addKeyListener(new java.awt.event.KeyAdapter() { 
                @Override
                public void keyReleased(java.awt.event.KeyEvent evt) { 
                    switch (evt.getKeyCode()) {
                        case VK_RIGHT:
                            siguientePregunta();
                            break;
                        case VK_LEFT:
                            anteriorPregunta();
                            break;
                        case VK_A:
                            pulsarRespuestaDesdeTeclado("A");
                            break;
                        case VK_B:
                            pulsarRespuestaDesdeTeclado("B");
                            break;
                        case VK_C:
                            pulsarRespuestaDesdeTeclado("C");
                            break;
                        case VK_D:
                            pulsarRespuestaDesdeTeclado("D");
                            break;
                        case VK_E:
                            pulsarRespuestaDesdeTeclado("E");
                            break;
                        case VK_F:
                            pulsarRespuestaDesdeTeclado("F");
                            break;
                        case VK_G:
                            pulsarRespuestaDesdeTeclado("G");
                            break;
                        case VK_H:
                            pulsarRespuestaDesdeTeclado("H");
                            break;
                        case VK_I:
                            pulsarRespuestaDesdeTeclado("I");
                            break;
                        case VK_J:
                            pulsarRespuestaDesdeTeclado("J");
                            break;
                        case VK_K:
                            pulsarRespuestaDesdeTeclado("K");
                            break;
                        default:
                            break;
                    }
                }
            });            
        }        
    }       
        
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panCuestionario = new javax.swing.JPanel();
        panBotones = new javax.swing.JPanel();
        btnSiguiente = new javax.swing.JButton();
        btnAnterior = new javax.swing.JButton();
        panPregunta = new javax.swing.JPanel();
        scpPregunta = new javax.swing.JScrollPane();
        txaPregunta = new javax.swing.JTextArea();
        panOpcionesRespuesta = new javax.swing.JPanel();
        scpOpcionesRespuesta = new javax.swing.JScrollPane();
        tblOpcionesRespuesta = new javax.swing.JTable();
        lblPregunta = new javax.swing.JLabel();
        txtNumeroPregunta = new javax.swing.JTextField();
        panImagen = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        btnSalir = new javax.swing.JButton();
        btnEvaluar = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("Cuestionario");
        setMinimumSize(new java.awt.Dimension(692, 670));
        setPreferredSize(new java.awt.Dimension(692, 670));

        panCuestionario.setBackground(new java.awt.Color(204, 255, 204));
        panCuestionario.setOpaque(false);

        panBotones.setOpaque(false);

        btnSiguiente.setText("Siguiente>");
        btnSiguiente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSiguienteActionPerformed(evt);
            }
        });

        btnAnterior.setText("<Anterior");
        btnAnterior.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnteriorActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panBotonesLayout = new javax.swing.GroupLayout(panBotones);
        panBotones.setLayout(panBotonesLayout);
        panBotonesLayout.setHorizontalGroup(
            panBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panBotonesLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnAnterior)
                .addGap(18, 18, 18)
                .addComponent(btnSiguiente)
                .addGap(268, 268, 268))
        );
        panBotonesLayout.setVerticalGroup(
            panBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panBotonesLayout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(panBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSiguiente)
                    .addComponent(btnAnterior))
                .addContainerGap())
        );

        scpPregunta.setBorder(null);

        txaPregunta.setEditable(false);
        txaPregunta.setBackground(new java.awt.Color(240, 240, 240));
        txaPregunta.setColumns(20);
        txaPregunta.setLineWrap(true);
        txaPregunta.setRows(5);
        txaPregunta.setBorder(null);
        txaPregunta.setFocusable(false);
        scpPregunta.setViewportView(txaPregunta);

        scpOpcionesRespuesta.setBorder(null);

        tblOpcionesRespuesta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "", "", ""
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblOpcionesRespuesta.getTableHeader().setReorderingAllowed(false);
        scpOpcionesRespuesta.setViewportView(tblOpcionesRespuesta);
        if (tblOpcionesRespuesta.getColumnModel().getColumnCount() > 0) {
            tblOpcionesRespuesta.getColumnModel().getColumn(0).setResizable(false);
            tblOpcionesRespuesta.getColumnModel().getColumn(0).setPreferredWidth(5);
            tblOpcionesRespuesta.getColumnModel().getColumn(1).setResizable(false);
            tblOpcionesRespuesta.getColumnModel().getColumn(1).setPreferredWidth(400);
            tblOpcionesRespuesta.getColumnModel().getColumn(2).setResizable(false);
            tblOpcionesRespuesta.getColumnModel().getColumn(2).setPreferredWidth(5);
        }

        javax.swing.GroupLayout panOpcionesRespuestaLayout = new javax.swing.GroupLayout(panOpcionesRespuesta);
        panOpcionesRespuesta.setLayout(panOpcionesRespuestaLayout);
        panOpcionesRespuestaLayout.setHorizontalGroup(
            panOpcionesRespuestaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panOpcionesRespuestaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(scpOpcionesRespuesta, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
                .addContainerGap())
        );
        panOpcionesRespuestaLayout.setVerticalGroup(
            panOpcionesRespuestaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panOpcionesRespuestaLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(scpOpcionesRespuesta, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        lblPregunta.setText("PREGUNTA");
        lblPregunta.setFocusable(false);

        txtNumeroPregunta.setEditable(false);
        txtNumeroPregunta.setBorder(null);
        txtNumeroPregunta.setFocusable(false);

        javax.swing.GroupLayout panImagenLayout = new javax.swing.GroupLayout(panImagen);
        panImagen.setLayout(panImagenLayout);
        panImagenLayout.setHorizontalGroup(
            panImagenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        panImagenLayout.setVerticalGroup(
            panImagenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 202, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout panPreguntaLayout = new javax.swing.GroupLayout(panPregunta);
        panPregunta.setLayout(panPreguntaLayout);
        panPreguntaLayout.setHorizontalGroup(
            panPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panPreguntaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(panImagen, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(scpPregunta, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panOpcionesRespuesta, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panPreguntaLayout.createSequentialGroup()
                        .addComponent(lblPregunta)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtNumeroPregunta, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        panPreguntaLayout.setVerticalGroup(
            panPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panPreguntaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPregunta)
                    .addComponent(txtNumeroPregunta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scpPregunta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panImagen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(panOpcionesRespuesta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        btnSalir.setMnemonic('S');
        btnSalir.setText("Salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        btnSalir.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btnSalirKeyPressed(evt);
            }
        });

        btnEvaluar.setMnemonic('E');
        btnEvaluar.setText("Evaluar");
        btnEvaluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEvaluarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnEvaluar)
                .addGap(69, 69, 69)
                .addComponent(btnSalir)
                .addGap(20, 20, 20))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSalir)
                    .addComponent(btnEvaluar)))
        );

        javax.swing.GroupLayout panCuestionarioLayout = new javax.swing.GroupLayout(panCuestionario);
        panCuestionario.setLayout(panCuestionarioLayout);
        panCuestionarioLayout.setHorizontalGroup(
            panCuestionarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panCuestionarioLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panCuestionarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panPregunta, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panBotones, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        panCuestionarioLayout.setVerticalGroup(
            panCuestionarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panCuestionarioLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panPregunta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(panBotones, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panCuestionario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(16, 16, 16))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panCuestionario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 11, Short.MAX_VALUE))
        );

        getAccessibleContext().setAccessibleParent(btnSalir);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void pulsarRespuestaDesdeTeclado(String strOpcionElegida){
        DefaultTableModel temp = (DefaultTableModel) tblOpcionesRespuesta.getModel();
        Integer iNumeroFilas = temp.getRowCount();
        if (iNumeroFilas > 0 ) {
            for (int k=0; k<iNumeroFilas; k++){
                //System.out.println(temp.getValueAt(k,0) + " " + strOpcionElegida);
                //System.out.println(temp.getValueAt(k, 0).toString().equals(strOpcionElegida));
                if (temp.getValueAt(k, 0).toString().equals(strOpcionElegida)){
                    if (temp.getValueAt(k,2).equals(false)){
                        temp.setValueAt(true,k,2);
                    }else{
                        temp.setValueAt(false,k,2);
                    }
                }
            }
        }  
    }
    
    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        this.dispose();       
    }//GEN-LAST:event_btnSalirActionPerformed
    
    private void btnSalirKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnSalirKeyPressed
        if ( evt.getKeyCode()== java.awt.event.KeyEvent.VK_ENTER ){
            this.dispose();
        }
    }//GEN-LAST:event_btnSalirKeyPressed
            
    private void borrarDatosPregunta(){        
        ponerDatosPregunta("","");
        borrarLineasTabla();
    }
    
    private void borrarLineasTabla(){
        DefaultTableModel temp = (DefaultTableModel) tblOpcionesRespuesta.getModel();
        Integer iNumeroFilas = temp.getRowCount();
        if (iNumeroFilas > 0 ) {
            for (int k=0; k<iNumeroFilas; k++){
                temp.removeRow(0);
            }
        }        
    }
    
    private void ponerDatosPregunta(String strNumero, String strEnunciado){
        
        //String strRImagen = "/imagenes/q";
        
        txtNumeroPregunta.setText(strNumero);
        txaPregunta.setText(strEnunciado);
        
//        strRImagen = strRImagen + strNumero + ".jpg";
//        if (strNumero.equals("1")){
//            ponerImagenesPregunta(strRImagen);
//        }
        
    }
    
    private void ponerImagenesPregunta(String strRutaImagen){
        Imagen im = new Imagen(panImagen);
        im.setRutaImagen(strRutaImagen);
        panImagen.add(im).repaint();
    }
    
    private void borrarImagenes(){
        panImagen.removeAll();
        panImagen.repaint();
    }
    
    private void cargarDatosPreguntaEnPantalla(Integer iNumeroPregunta, Object[][] objPregunta){
        
        borrarDatosPregunta();
        
        borrarImagenes();
        
        //ponerDatosPregunta(objPregunta[iNumeroPregunta][j].toString(), objPregunta[iNumeroPregunta][j+1].toString());
        ponerDatosPregunta(iNumeroPregunta.toString(), iterator.next().getTextoPregunta());
        
        cargarOpcionesRespuestaEnPantalla(Integer.parseInt(objPregunta[iNumeroPregunta][0].toString()), conBD);
        //cargarOpcionesRespuestaEnPantalla(arlPreguntas.get(iNumeroPregunta).getNumeroPregunta(), conBD);
        
    }
    
    private void cargarOpcionesRespuestaEnPantalla(Integer iNumeroPregunta, Connection conBD){
        Boolean bolOpcion = false;        
        
        objOpcionesRespuesta = accBD.obtenerOpcionesRespuestaFiltradoPorNumeroDePregunta(iNumeroPregunta, conBD);
        
        if ( objOpcionesRespuesta != null ){
            DefaultTableModel temp = (DefaultTableModel) tblOpcionesRespuesta.getModel();
                        
            for (int i=0;i<objOpcionesRespuesta.length;i++){                
                //bolOpcion = false;
                temp.addRow(new Object[] {objOpcionesRespuesta[i][0].toString(),objOpcionesRespuesta[i][1].toString(),bolOpcion});
            }
        }
    }
    
    private void cargarListaDePreguntas(Object[][] objPregunta) {
        
        Pregunta prePregunta = new Pregunta();
        Integer i;
        
        i=0;
        
        while ( i<objPregunta.length ) {
            
            prePregunta.setPosicionPregunta(i);
            prePregunta.setNumeroPregunta(Integer.parseInt(objPregunta[i][0].toString())); 
            prePregunta.setTextoPregunta(objPregunta[i][1].toString());
            arlPreguntas.add(i, prePregunta);
            i = i + 1; 
            
        }
        
    }
        
    private void cargarValoresRespuestaEnLista(Integer iNumeroPregunta, ArrayList<Respuesta> arlRespuestas) {
        
        Respuesta resRespuesta = new Respuesta();
        ArrayList<String> aliValores = new ArrayList<>();
        
        if ((iNumeroPregunta + 1) > arlRespuestas.size()) {
        
            //Ponemos el número de respuesta
            resRespuesta.setNumeroRespuesta(iNumeroPregunta);        

            DefaultTableModel temp = (DefaultTableModel) tblOpcionesRespuesta.getModel();

            //Recorremos la tabla de opciones, y ponemos las respuestas correctas a "T" y las respuestas falsas a "F"
            for (int i=0;i<temp.getRowCount();i++){   
                if (temp.getValueAt(i, 2).equals(true)){
                    aliValores.add(i, "T");
                } else {
                    aliValores.add(i, "F");
                }
            }

            resRespuesta.setRespuestasElegidas(aliValores);
            arlRespuestas.add(iNumeroPregunta, resRespuesta);
            
        } else {
            
            DefaultTableModel temp = (DefaultTableModel) tblOpcionesRespuesta.getModel();

            //Recorremos la tabla de opciones, y ponemos las respuestas correctas a "T" y las respuestas falsas a "F"
            for (int i=0;i<temp.getRowCount();i++){   
                if (temp.getValueAt(i, 2).equals(true)){
                    aliValores.add(i, "T");
                } else {
                    aliValores.add(i, "F");
                }
            }
            
            arlRespuestas.get(iNumeroPregunta).setRespuestasElegidas(aliValores);
            arlRespuestas.set(iNumeroPregunta, arlRespuestas.get(iNumeroPregunta));
        }
        
        //System.out.println("cargarValaresRespuestaEnLista " + iNumeroPregunta + " " + arlRespuestas.get(iNumeroPregunta) + " " + arlRespuestas.get(iNumeroPregunta).getNumeroRespuesta() + " " + arlRespuestas.get(iNumeroPregunta).getRespuestasElegidas() );
        
    }
    
    private void cargarValoresRespuestaEnPantalla(Integer iNumeroPregunta, ArrayList<Respuesta> arlRespuestas) {
        String strValorElegido;
        Boolean bolValorElegido = false;
        Respuesta resRespuesta;
        
        if (arlRespuestas != null & iNumeroPregunta < arlRespuestas.size()) {
        
            resRespuesta = arlRespuestas.get(iNumeroPregunta);
            
            //System.out.println("cargarValoresRespuestaEnPantalla " + iNumeroPregunta + " " + resRespuesta + " " + resRespuesta.getNumeroRespuesta() + " " + resRespuesta.getRespuestasElegidas());

            DefaultTableModel temp = (DefaultTableModel) tblOpcionesRespuesta.getModel();
            if ( temp != null ){            
                Iterator<String> iteValoresElegidos = resRespuesta.getRespuestasElegidas().iterator();
                for (int i=0;i<temp.getRowCount();i++){                
                    strValorElegido=iteValoresElegidos.next();
                    bolValorElegido = strValorElegido.equals("T");
                    temp.setValueAt(bolValorElegido, i, 2);
                }
            }
        
        }
        
    }
    
    private void siguientePregunta(){
        
        cargarValoresRespuestaEnLista(iNumeroPreguntaActual, arlRespuestas);
        iNumeroPreguntaActual = iNumeroPreguntaActual + 1;
        
        if (iNumeroPreguntaActual+1>iNumeroPrimeraPregunta){
            btnAnterior.setEnabled(true);
        }
       
        if ( objPregunta.length > iNumeroPreguntaActual ){                                 
            cargarDatosPreguntaEnPantalla(iNumeroPreguntaActual, objPregunta);
            cargarValoresRespuestaEnPantalla(iNumeroPreguntaActual, arlRespuestas);
        } else {
            iNumeroPreguntaActual = iNumeroPreguntaActual - 1;
        }
        
        if (iNumeroPreguntaActual.equals(iNumeroUltimaPregunta-1)){
            btnSiguiente.setEnabled(false);
        }
    }
    
    private void anteriorPregunta (){
        
        cargarValoresRespuestaEnLista(iNumeroPreguntaActual, arlRespuestas);        
        iNumeroPreguntaActual = iNumeroPreguntaActual - 1;
        
        if (iNumeroPreguntaActual<iNumeroUltimaPregunta-1){
            btnSiguiente.setEnabled(true);
        }
        
        if ( iNumeroPreguntaActual >= 0 ){            
            cargarDatosPreguntaEnPantalla(iNumeroPreguntaActual, objPregunta);
            cargarValoresRespuestaEnPantalla(iNumeroPreguntaActual, arlRespuestas);
        } else {
            iNumeroPreguntaActual = iNumeroPreguntaActual + 1;
        } 
        
        if (iNumeroPreguntaActual.equals(iNumeroPrimeraPregunta-1)){
            btnAnterior.setEnabled(false);
        }
        
    }
    
    private void btnSiguienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSiguienteActionPerformed
        siguientePregunta();
    }//GEN-LAST:event_btnSiguienteActionPerformed

    private void btnAnteriorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnteriorActionPerformed
        anteriorPregunta();
    }//GEN-LAST:event_btnAnteriorActionPerformed

    private Integer contarPreguntasContestadas(){
        Integer iResultado;
        Respuesta resRespuesta;
        resRespuesta = null;
        
        iResultado = 0;
        Iterator<Respuesta> iteRespuestas = arlRespuestas.iterator();
        while (iteRespuestas.hasNext()){
            resRespuesta = iteRespuestas.next();
            if (resRespuesta.getRespuestasElegidas().contains("T")){
                iResultado = iResultado + 1;
            }
        }
        
        return iResultado;
    }
    
    private Boolean validarRespuestas(Integer iNumeroPregunta, ArrayList<String> arlLista){
        Boolean bolResultado;
        bolResultado = true;        
        Integer iNPregunta;
        Object[][] objValidarRespuesta; 
//        System.out.println("Número de pregunta: " + iNumeroPregunta);
        
        iNPregunta = iNumeroPregunta + 1;
        objValidarRespuesta = accBD.obtenerValoresRespuestaFiltradoPorNumeroDePregunta(iNPregunta, conBD);
        
        if ( objValidarRespuesta != null ){
            for (int k=0;k<objValidarRespuesta.length;k++){
//                System.out.println(objValidarRespuesta[k][2] + "=" + arlLista.get(k));
//                System.out.println(objValidarRespuesta[k][2].equals(arlLista.get(k)));
                if (objValidarRespuesta[k][2].equals(arlLista.get(k))){
                    bolResultado = bolResultado & true;
                } else {
                    bolResultado = bolResultado & false;
                }
            }
        } else {
            bolResultado = bolResultado & false;
        }       
        return bolResultado;
    }
    
    private Integer contarPreguntasCorrectas(){
        Integer iResultado;
        Respuesta resRespuesta;
        resRespuesta = null;
        
        iResultado = 0;
        Iterator<Respuesta> iteRespuestas = arlRespuestas.iterator();
        while (iteRespuestas.hasNext()){
            resRespuesta = iteRespuestas.next();
            if (validarRespuestas(Integer.parseInt(resRespuesta.getNumeroRespuesta().toString()), resRespuesta.getRespuestasElegidas())){
                iResultado = iResultado + 1;
            }            
        }
        
        return iResultado;
    }
    
    
    private void btnEvaluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEvaluarActionPerformed
        
        Integer iPreguntasTotales;
        Integer iPreguntasLeidas;
        Integer iPreguntasContestadas;
        Integer iPreguntasCorrectas;
        Integer iTantoPorCiento;
        
        cargarValoresRespuestaEnLista(iNumeroPreguntaActual, arlRespuestas);
        
        iPreguntasTotales = arlPreguntas.size();
        iPreguntasLeidas = arlRespuestas.size();
        
        iPreguntasContestadas = contarPreguntasContestadas();
        
        iPreguntasCorrectas = contarPreguntasCorrectas();
        
        if (iPreguntasCorrectas > 0 ) {
            iTantoPorCiento = iPreguntasCorrectas * 100 / iPreguntasTotales;
        } else {
            iTantoPorCiento = 0;
        }
            
        Resultados diaResultados = Resultados.getInstance();
        
        txtResPreguntasTotales.setText(iPreguntasTotales.toString());
        txtResPreguntasLeidas.setText(iPreguntasLeidas.toString());
        txtResPreguntasContestadas.setText(iPreguntasContestadas.toString());
        txtResPreguntasCorrectas.setText(iPreguntasCorrectas.toString());
        txtResTantoPorCientoContestadas.setText(iTantoPorCiento.toString());
        
        diaResultados.setLocationRelativeTo(null);
        diaResultados.setVisible(true);         
        
    }//GEN-LAST:event_btnEvaluarActionPerformed
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAnterior;
    private javax.swing.JButton btnEvaluar;
    private javax.swing.JButton btnSalir;
    private javax.swing.JButton btnSiguiente;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblPregunta;
    private javax.swing.JPanel panBotones;
    private javax.swing.JPanel panCuestionario;
    private javax.swing.JPanel panImagen;
    private javax.swing.JPanel panOpcionesRespuesta;
    private javax.swing.JPanel panPregunta;
    private javax.swing.JScrollPane scpOpcionesRespuesta;
    private javax.swing.JScrollPane scpPregunta;
    private javax.swing.JTable tblOpcionesRespuesta;
    private javax.swing.JTextArea txaPregunta;
    private javax.swing.JTextField txtNumeroPregunta;
    // End of variables declaration//GEN-END:variables

}