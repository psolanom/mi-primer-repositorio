/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cuestionario;

import static cuestionario.PantallaPrincipal.accBD;
import static cuestionario.PantallaPrincipal.conBD;
import static cuestionario.PantallaPrincipal.dpaPantallaPrincipal;
import static cuestionario.Resultados.txtResPreguntasContestadas;
import static cuestionario.Resultados.txtResPreguntasCorrectas;
import static cuestionario.Resultados.txtResPreguntasLeidas;
import static cuestionario.Resultados.txtResPreguntasTotales;
import static cuestionario.Resultados.txtResTantoPorCiento;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import static cuestionario.Resultados.txtResTantoPorCientoContestadas;
import static cuestionario.VistaImagenPregunta.panImagen;
import java.beans.PropertyVetoException;
import java.util.logging.Level;
import java.util.logging.Logger;
import parametrizacion.MantPreguntas;

/**
 *
 * @author p.solano
 *
 */

public class Formulario extends javax.swing.JInternalFrame {
    
    private VistaImagenPregunta ifmVistaImagenPregunta;
    
    ArrayList<Pregunta>     arlPreguntas;
    ArrayList<Respuesta>    arlRespuestas;
    
    Integer iPosicionActual;
    Integer iTotalPreguntas;
    
    public Formulario() throws InstantiationException, IllegalAccessException, SQLException {
        
        Object[][]              objPregunta;
        Pregunta                prePregunta;
        
        initComponents();
        
        //Obtenemos las preguntas y las guardamos en el objeto Pregunta
        objPregunta = accBD.obtenerPreguntas2(conBD);
        
        //Instanciamos la lista de respuestas
        arlPreguntas = new ArrayList<>();
        
        cargarListaDePreguntas(objPregunta, arlPreguntas);
        
        iTotalPreguntas = arlPreguntas.size();
        iPosicionActual = 0;
        
        //Instanciamos la lista de respuestas
        arlRespuestas = new ArrayList<>();
        
        prePregunta = arlPreguntas.get(iPosicionActual);
                        
        mostrarPorPantallaPregunta(prePregunta);
        
        btnAnterior.setEnabled(false);
        
    }
    
    private void borrarImagenes(JPanel panImagen){
        panImagen.removeAll();
        panImagen.repaint();
    }
    
    private void borrarLineasTabla(){
        DefaultTableModel temp = (DefaultTableModel) tblOpciones.getModel();
        Integer iNumeroFilas = temp.getRowCount();
        if (iNumeroFilas > 0 ) {
            for (int k=0; k<iNumeroFilas; k++){
                temp.removeRow(0);
            }
        }        
    }
    
    private void ponerImagenesPregunta(JPanel panImagen, String strRutaImagen){
        Imagen imImagen = new Imagen(panImagen);
        imImagen.setRutaImagen(strRutaImagen);
        panImagen.add(imImagen).repaint();
                
    }
    
    private void mostrarPorPantallaPregunta(Pregunta prePregunta){
        
        ArrayList<Opcion>   arlOpciones;
        Iterator<Opcion>    iteOpciones;
        Opcion              opcOpcion;
        Boolean             bolOpcion = false;
        Integer             i;
        
        //Cargamos la pregunta
        txtPosicionPregunta.setText(prePregunta.getPosicionPregunta().toString());
        txtNumeroPregunta.setText(prePregunta.getNumeroPregunta().toString());
        txaPregunta.setText(prePregunta.getTextoPregunta());
        
        //Cargamos imagen, si la hubiese
//        borrarImagenes(panImagen);
//        
//        if (!"".equals(prePregunta.getImagenPregunta())){
//            JPanel panI = new JPanel();
//        
//            panI.setSize(290,190);
//            panImagen.add(panI);  
//            
//            ponerImagenesPregunta(panI, prePregunta.getImagenPregunta());            
//        }
        
        //Cargamos opciones de respuesta
        borrarLineasTabla();
        
        if (prePregunta.getOpciones()!= null){
            
            arlOpciones = prePregunta.getOpciones();
            iteOpciones = arlOpciones.iterator();
        
            DefaultTableModel temp = (DefaultTableModel) tblOpciones.getModel();
            i=0;
            while (iteOpciones.hasNext()){
                opcOpcion = iteOpciones.next();
                temp.addRow(new Object[] {opcOpcion.getCaracterOpcion(),opcOpcion.getTextoOpcion(),bolOpcion});
                
            }
        }
        
    }
        
    private void cargarListaDePreguntas(Object[][] objPregunta, ArrayList<Pregunta> arlPreguntas) {
        
        Pregunta prePregunta;
        Integer i;
        Integer j;
        Object[][] objOpcion;
        
        i=0;
        
        if (objPregunta != null) {
            while ( i<objPregunta.length ) {
                prePregunta = new Pregunta();
                
                prePregunta.setPosicionPregunta(i);
                prePregunta.setNumeroPregunta(Integer.parseInt(objPregunta[i][0].toString())); 
                prePregunta.setTextoPregunta(objPregunta[i][1].toString());
                if ( objPregunta[i][2] != null){
                    prePregunta.setImagenPregunta(objPregunta[i][2].toString());
                } else {
                    prePregunta.setImagenPregunta("");
                }
                
                objOpcion = accBD.obtenerOpcionesRespuestaFiltradoPorNumeroDePregunta2(prePregunta.getNumeroPregunta(), conBD);
                
                j=0;
                if (objOpcion != null ){
                    
                    ArrayList<Opcion> arlOpciones;
                    arlOpciones = new ArrayList<>();
                    
                    while ( j<objOpcion.length ) { 
                        
                        Opcion opcOpcion = new Opcion();
                        
                        opcOpcion.setNumeroPregunta(Integer.parseInt(objOpcion[j][0].toString()));
                        opcOpcion.setNumeroOpcion(Integer.parseInt(objOpcion[j][1].toString()));
                        opcOpcion.setCaracterOpcion(objOpcion[j][2].toString());
                        opcOpcion.setTextoOpcion(objOpcion[j][3].toString());
                        opcOpcion.setEsCorrecta(objOpcion[j][4].toString());
                        
                        arlOpciones.add(j, opcOpcion);
                        
                        j = j + 1;
                        
                    }
                    prePregunta.setOpciones(arlOpciones);
                }
                
                arlPreguntas.add(i, prePregunta);
                i = i + 1; 
            }
        }
        
    }
    
    private ArrayList<String> cargarValoresRespuestas(){
        
        ArrayList<String>
                
        arlValores = new ArrayList<>();
        
        DefaultTableModel temp = (DefaultTableModel) tblOpciones.getModel();

        //Recorremos la tabla de opciones, y ponemos las respuestas correctas a "T" y las respuestas falsas a "F"
        for (int i=0;i<temp.getRowCount();i++){   
            if (temp.getValueAt(i, 2).equals(true)){
                arlValores.add(i, "T");
            } else {
                arlValores.add(i, "F");
            }
        }
        return arlValores;
    }
    
    private void cargarListaDeRespuestas(Pregunta prePregunta, ArrayList<Respuesta> arlRespuestas) {
        
        Respuesta  resRespuesta;  
        
        if (prePregunta.getPosicionPregunta() >= arlRespuestas.size()) {
            
            resRespuesta = new Respuesta();
            //Ponemos los datos de la respuesta
            resRespuesta.setNumeroPregunta(prePregunta.getNumeroPregunta());
            resRespuesta.setNumeroRespuesta(prePregunta.getPosicionPregunta());        
            resRespuesta.setRespuestasElegidas(cargarValoresRespuestas());
            
            arlRespuestas.add(prePregunta.getPosicionPregunta(), resRespuesta);
            
        } else {
            arlRespuestas.get(prePregunta.getPosicionPregunta()).setRespuestasElegidas(cargarValoresRespuestas());
            arlRespuestas.set(prePregunta.getPosicionPregunta(), arlRespuestas.get(prePregunta.getPosicionPregunta()));
        }
        
//        System.out.println("cargarListaDeRespuestas " + prePregunta.getPosicionPregunta() + " " + arlRespuestas.get(prePregunta.getPosicionPregunta()) + " " + arlRespuestas.get(prePregunta.getPosicionPregunta()).getNumeroRespuesta() + " " + arlRespuestas.get(prePregunta.getPosicionPregunta()).getRespuestasElegidas() );
        
    }
    
    private void mostrarPorPantallaRespuestas(Integer iNumeroPregunta, ArrayList<Respuesta> arlRespuestas) {
        String strValorElegido;
        Boolean bolValorElegido = false;
        Respuesta resRespuesta;
        
        if (arlRespuestas != null & iNumeroPregunta < arlRespuestas.size()) {
        
            resRespuesta = arlRespuestas.get(iNumeroPregunta);
            
            //System.out.println("mostrarPorPantallaRespuestas " + iNumeroPregunta + " " + resRespuesta + " " + resRespuesta.getNumeroRespuesta() + " " + resRespuesta.getRespuestasElegidas());

            DefaultTableModel temp = (DefaultTableModel) tblOpciones.getModel();
            if ( temp != null ){            
                Iterator<String> iteValoresElegidos = resRespuesta.getRespuestasElegidas().iterator();
                for (int i=0;i<temp.getRowCount();i++){                
                    strValorElegido=iteValoresElegidos.next();
                    bolValorElegido = strValorElegido.equals("T");
                    temp.setValueAt(bolValorElegido, i, 2);
                }
            }
        
        }
        
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panCuestionario = new javax.swing.JPanel();
        panBotones = new javax.swing.JPanel();
        btnSiguiente = new javax.swing.JButton();
        btnAnterior = new javax.swing.JButton();
        panPregunta = new javax.swing.JPanel();
        scpPregunta = new javax.swing.JScrollPane();
        txaPregunta = new javax.swing.JTextArea();
        lblPregunta = new javax.swing.JLabel();
        txtNumeroPregunta = new javax.swing.JTextField();
        txtPosicionPregunta = new javax.swing.JTextField();
        lblPregunta1 = new javax.swing.JLabel();
        btnImagen = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblOpciones = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        btnSalir = new javax.swing.JButton();
        btnEvaluar = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("Cuestionario");
        setMinimumSize(new java.awt.Dimension(692, 670));
        setPreferredSize(new java.awt.Dimension(692, 670));

        panCuestionario.setBackground(new java.awt.Color(204, 255, 204));
        panCuestionario.setOpaque(false);

        panBotones.setOpaque(false);

        btnSiguiente.setText("Siguiente");
        btnSiguiente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSiguienteActionPerformed(evt);
            }
        });

        btnAnterior.setText("Anterior");
        btnAnterior.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnteriorActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panBotonesLayout = new javax.swing.GroupLayout(panBotones);
        panBotones.setLayout(panBotonesLayout);
        panBotonesLayout.setHorizontalGroup(
            panBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panBotonesLayout.createSequentialGroup()
                .addContainerGap(311, Short.MAX_VALUE)
                .addComponent(btnAnterior)
                .addGap(18, 18, 18)
                .addComponent(btnSiguiente)
                .addGap(152, 152, 152))
        );
        panBotonesLayout.setVerticalGroup(
            panBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panBotonesLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(panBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSiguiente)
                    .addComponent(btnAnterior))
                .addGap(112, 112, 112))
        );

        scpPregunta.setBorder(null);

        txaPregunta.setEditable(false);
        txaPregunta.setBackground(new java.awt.Color(240, 240, 240));
        txaPregunta.setColumns(20);
        txaPregunta.setLineWrap(true);
        txaPregunta.setRows(5);
        txaPregunta.setBorder(null);
        txaPregunta.setFocusable(false);
        scpPregunta.setViewportView(txaPregunta);

        lblPregunta.setText("PREGUNTA:");
        lblPregunta.setFocusable(false);

        txtNumeroPregunta.setEditable(false);
        txtNumeroPregunta.setBorder(null);
        txtNumeroPregunta.setFocusable(false);

        txtPosicionPregunta.setEditable(false);
        txtPosicionPregunta.setBorder(null);
        txtPosicionPregunta.setFocusable(false);

        lblPregunta1.setText("POSICION:");
        lblPregunta1.setFocusable(false);

        btnImagen.setText("Imagen");
        btnImagen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImagenActionPerformed(evt);
            }
        });

        tblOpciones.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "", "", ""
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblOpciones);
        if (tblOpciones.getColumnModel().getColumnCount() > 0) {
            tblOpciones.getColumnModel().getColumn(0).setResizable(false);
            tblOpciones.getColumnModel().getColumn(0).setPreferredWidth(2);
            tblOpciones.getColumnModel().getColumn(1).setPreferredWidth(500);
            tblOpciones.getColumnModel().getColumn(2).setResizable(false);
            tblOpciones.getColumnModel().getColumn(2).setPreferredWidth(2);
        }

        javax.swing.GroupLayout panPreguntaLayout = new javax.swing.GroupLayout(panPregunta);
        panPregunta.setLayout(panPreguntaLayout);
        panPreguntaLayout.setHorizontalGroup(
            panPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panPreguntaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(scpPregunta, javax.swing.GroupLayout.DEFAULT_SIZE, 620, Short.MAX_VALUE)
                    .addGroup(panPreguntaLayout.createSequentialGroup()
                        .addComponent(lblPregunta)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtNumeroPregunta, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblPregunta1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPosicionPregunta, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panPreguntaLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnImagen)))
                .addContainerGap())
        );
        panPreguntaLayout.setVerticalGroup(
            panPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panPreguntaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPregunta)
                    .addComponent(txtNumeroPregunta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPosicionPregunta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblPregunta1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scpPregunta, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnImagen)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout panCuestionarioLayout = new javax.swing.GroupLayout(panCuestionario);
        panCuestionario.setLayout(panCuestionarioLayout);
        panCuestionarioLayout.setHorizontalGroup(
            panCuestionarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panCuestionarioLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panPregunta, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panCuestionarioLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(panBotones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        panCuestionarioLayout.setVerticalGroup(
            panCuestionarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panCuestionarioLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panPregunta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                .addComponent(panBotones, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        btnSalir.setMnemonic('S');
        btnSalir.setText("Salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        btnSalir.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btnSalirKeyPressed(evt);
            }
        });

        btnEvaluar.setMnemonic('E');
        btnEvaluar.setText("Evaluar");
        btnEvaluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEvaluarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(btnEvaluar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSalir)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSalir)
                    .addComponent(btnEvaluar))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panCuestionario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(16, 16, 16))
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panCuestionario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getAccessibleContext().setAccessibleParent(btnSalir);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSalirKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnSalirKeyPressed
        if ( evt.getKeyCode()== java.awt.event.KeyEvent.VK_ENTER ){
            this.dispose();
        }
    }//GEN-LAST:event_btnSalirKeyPressed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnSiguienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSiguienteActionPerformed
                
        if (iPosicionActual < iTotalPreguntas - 1 ) {
            cargarListaDeRespuestas(arlPreguntas.get(iPosicionActual), arlRespuestas);
            iPosicionActual = iPosicionActual + 1;            
            mostrarPorPantallaPregunta(arlPreguntas.get(iPosicionActual));
            mostrarPorPantallaRespuestas(iPosicionActual, arlRespuestas);
            btnAnterior.setEnabled(true);
            if (iPosicionActual == iTotalPreguntas - 1 ) {
                 btnSiguiente.setEnabled(false);
            }
        }
        
    }//GEN-LAST:event_btnSiguienteActionPerformed

    private void btnAnteriorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnteriorActionPerformed
                
        if (iPosicionActual > 0 ) {
            cargarListaDeRespuestas(arlPreguntas.get(iPosicionActual), arlRespuestas);
            iPosicionActual = iPosicionActual - 1;
            mostrarPorPantallaPregunta(arlPreguntas.get(iPosicionActual));
            mostrarPorPantallaRespuestas(iPosicionActual, arlRespuestas);
            btnSiguiente.setEnabled(true);
            if (iPosicionActual == 0 ) {
                 btnAnterior.setEnabled(false);
            }
        }           
        
    }//GEN-LAST:event_btnAnteriorActionPerformed
    
    private Integer contarPreguntasContestadas(ArrayList<Respuesta> arlRespuestas){
        Integer iResultado;
        Respuesta resRespuesta;
        Iterator<Respuesta> iteRespuestas;
                
        iResultado = 0;
        iteRespuestas = arlRespuestas.iterator();
        while (iteRespuestas.hasNext()){
            resRespuesta = iteRespuestas.next();
            if (resRespuesta.getRespuestasElegidas().contains("T")){
                iResultado = iResultado + 1;
            }
        }        
        return iResultado;
    }
    
    private Boolean validarRespuestas(Integer iNumeroPregunta, ArrayList<String> arlRespuesta){
        Boolean bolResultado;
        bolResultado = true;        
        Object[][] objValidarRespuesta; 
      
//        System.out.println("Número de pregunta en validar Respuestas: " + iNumeroPregunta);
        
        objValidarRespuesta = accBD.obtenerValoresRespuestaFiltradoPorNumeroDePregunta(iNumeroPregunta, conBD);
        
        if ( objValidarRespuesta != null & arlRespuesta != null & arlRespuesta.contains("T")){
            for (int k=0;k<objValidarRespuesta.length;k++){
//                System.out.println(objValidarRespuesta[k][2] + "=" + arlLista.get(k));
//                System.out.println(objValidarRespuesta[k][2].equals(arlLista.get(k)));
                if (objValidarRespuesta[k][2].equals(arlRespuesta.get(k))){
                    bolResultado = bolResultado & true;
                } else {
                    bolResultado = bolResultado & false;
                }
            }
        } else {
            bolResultado = bolResultado & false;
        }       
        return bolResultado;
    }
    
    private Integer contarPreguntasCorrectas(ArrayList<Respuesta> arlRespuestas){
        Integer iResultado;
        Respuesta resRespuesta;
        Iterator<Respuesta> iteRespuestas;
                
        iResultado = 0;
        iteRespuestas = arlRespuestas.iterator();
        while (iteRespuestas.hasNext()){
            resRespuesta = iteRespuestas.next();
            if (validarRespuestas(Integer.parseInt(resRespuesta.getNumeroPregunta().toString()), resRespuesta.getRespuestasElegidas())){
                iResultado = iResultado + 1;
            }            
        }
        
        return iResultado;
    }
    
    private void btnEvaluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEvaluarActionPerformed

        Integer iPreguntasTotales;
        Integer iPreguntasLeidas;
        Integer iPreguntasContestadas;
        Integer iPreguntasCorrectas;
        Integer iTantoPorCientoContestadas;
        Integer iTantoPorCiento;

        cargarListaDeRespuestas(arlPreguntas.get(iPosicionActual), arlRespuestas);

        iPreguntasTotales = arlPreguntas.size();
        iPreguntasLeidas = arlRespuestas.size();

        iPreguntasContestadas = contarPreguntasContestadas(arlRespuestas);

        iPreguntasCorrectas = contarPreguntasCorrectas(arlRespuestas);
        
        if (iPreguntasContestadas > 0 ){
            iTantoPorCientoContestadas = iPreguntasCorrectas * 100 / iPreguntasContestadas;
        } else {
            iTantoPorCientoContestadas = 0;
        }
        iTantoPorCiento = iPreguntasCorrectas * 100 / iPreguntasTotales;
        

        Resultados diaResultados = Resultados.getInstance();

        txtResPreguntasTotales.setText(iPreguntasTotales.toString());
        txtResPreguntasLeidas.setText(iPreguntasLeidas.toString());
        txtResPreguntasContestadas.setText(iPreguntasContestadas.toString());
        txtResPreguntasCorrectas.setText(iPreguntasCorrectas.toString());
        txtResTantoPorCientoContestadas.setText(iTantoPorCientoContestadas.toString());
        txtResTantoPorCiento.setText(iTantoPorCiento.toString());

        diaResultados.setLocationRelativeTo(null);
        diaResultados.setVisible(true);

    }//GEN-LAST:event_btnEvaluarActionPerformed

    private void btnImagenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImagenActionPerformed
        
        if ( ifmVistaImagenPregunta == null || !ifmVistaImagenPregunta.isVisible() ){
        
            ifmVistaImagenPregunta = new VistaImagenPregunta();
            dpaPantallaPrincipal.add(ifmVistaImagenPregunta);
            
            //Cargamos imagen, si la hubiese
            //borrarImagenes(panImagen);
        
            System.out.println("Imagen: " + arlPreguntas.get(iPosicionActual).getImagenPregunta());
            
            if (!"".equals(arlPreguntas.get(iPosicionActual).getImagenPregunta())){
                JPanel panI = new JPanel();
        
                panI.setSize(290,190);
                panImagen.add(panI);
                panImagen.setVisible(true);
            
                ponerImagenesPregunta(panI, arlPreguntas.get(iPosicionActual).getImagenPregunta());            
            }
            
            ifmVistaImagenPregunta.setVisible(true);
        
        } else {
            if ( ifmVistaImagenPregunta != null && ifmVistaImagenPregunta.isVisible() && ifmVistaImagenPregunta.isIcon()){
                try {
                    ifmVistaImagenPregunta.setIcon(false);
                } catch (PropertyVetoException ex) {
                    Logger.getLogger(PantallaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        
    }//GEN-LAST:event_btnImagenActionPerformed
        
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAnterior;
    private javax.swing.JButton btnEvaluar;
    private javax.swing.JButton btnImagen;
    private javax.swing.JButton btnSalir;
    private javax.swing.JButton btnSiguiente;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblPregunta;
    private javax.swing.JLabel lblPregunta1;
    private javax.swing.JPanel panBotones;
    private javax.swing.JPanel panCuestionario;
    private javax.swing.JPanel panPregunta;
    private javax.swing.JScrollPane scpPregunta;
    private javax.swing.JTable tblOpciones;
    private javax.swing.JTextArea txaPregunta;
    private javax.swing.JTextField txtNumeroPregunta;
    private javax.swing.JTextField txtPosicionPregunta;
    // End of variables declaration//GEN-END:variables

}