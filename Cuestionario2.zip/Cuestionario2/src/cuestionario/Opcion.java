/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cuestionario;

/**
 *
 * @author Pedro
 */
public class Opcion {
    
    private Integer  NumeroPregunta;
    private Integer  NumeroOpcion;
    
    private String  CaracterOpcion;
    private String  TextoOpcion;
    
    private String  EsCorrecta;

    public Integer getNumeroPregunta() {
        return NumeroPregunta;
    }

    public Integer getNumeroOpcion() {
        return NumeroOpcion;
    }

    public String getCaracterOpcion() {
        return CaracterOpcion;
    }

    public String getTextoOpcion() {
        return TextoOpcion;
    }

    public String getEsCorrecta() {
        return EsCorrecta;
    }
    
    public void setNumeroPregunta(Integer NumeroPregunta) {
        this.NumeroPregunta = NumeroPregunta;
    }

    public void setNumeroOpcion(Integer NumeroOpcion) {
        this.NumeroOpcion = NumeroOpcion;
    }

    public void setCaracterOpcion(String CaracterOpcion) {
        this.CaracterOpcion = CaracterOpcion;
    }

    public void setTextoOpcion(String TextoOpcion) {
        this.TextoOpcion = TextoOpcion;
    }

    public void setEsCorrecta(String EsCorrecta) {
        this.EsCorrecta = EsCorrecta;
    }
    
    
}
