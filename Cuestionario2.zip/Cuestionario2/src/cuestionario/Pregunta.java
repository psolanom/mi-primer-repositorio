/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cuestionario;

import java.util.ArrayList;

/**
 *
 * @author Pedro
 */
public class Pregunta {
    
    private Integer             PosicionPregunta;
    private Integer             NumeroPregunta;
    private String              TextoPregunta;
    private String              ImagenPregunta;
    private ArrayList<Opcion>   Opciones;

    public void setOpciones(ArrayList<Opcion> Opciones) {
        this.Opciones = Opciones;
    }

    public ArrayList<Opcion> getOpciones() {
        return Opciones;
    }

    public void setImagenPregunta(String ImagenPregunta) {
        this.ImagenPregunta = ImagenPregunta;
    }

    public String getImagenPregunta() {
        return ImagenPregunta;
    }

    public void setPosicionPregunta(Integer PosicionPregunta) {
        this.PosicionPregunta = PosicionPregunta;
    }

    public Integer getPosicionPregunta() {
        return PosicionPregunta;
    }

    public void setNumeroPregunta(Integer NumeroPregunta) {
        this.NumeroPregunta = NumeroPregunta;
    }

    public void setTextoPregunta(String TextoPregunta) {
        this.TextoPregunta = TextoPregunta;
    }

    public Integer getNumeroPregunta() {
        return NumeroPregunta;
    }

    public String getTextoPregunta() {
        return TextoPregunta;
    }    
    
    public Pregunta() {
    }
    
}
