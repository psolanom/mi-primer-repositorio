 /*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package accesodatos;

import java.io.File;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/*
 *
 * @author 
 * 
 */

public class AccesoBDMySQL {
    
    private Connection conBaseDatos;
    
    public Connection accederBaseDatos() throws ClassNotFoundException, SQLException{
        
        //Obtenemos el driver de para JDB (MySQL)
        Class.forName("com.mysql.jdbc.Driver");
         
        //Obtenemos la conexión
        conBaseDatos = DriverManager.getConnection("jdbc:mysql://localhost/questionary", "admin", "MySQL16.");
            
        if ( conBaseDatos != null ){
            
            System.out.println("Se ha conectado a la base de datos");
            
//            JOptionPane.showMessageDialog(
//                null,
//                "Se ha accedido correctamente a la base de datos",
//                "Información",
//                JOptionPane.INFORMATION_MESSAGE);
        
        } else {
            
            System.out.println("No se ha conectado a la base de datos");
            
        }
        
        return conBaseDatos;
    
    }
    
    //Función para comprobar si existe ya la base de datos.
    public boolean existeBaseDatos(String strRuta){
        
        boolean bolResultado = false;
        File filBaseDatos = new File(strRuta);
        
        if (filBaseDatos.isDirectory()){
            bolResultado = true;
        }
        return bolResultado;
        
    }
    
    //Procedimiento para cerrar la base de datos
    public void cerrarBaseDatos(){
        
        try {
            
            conBaseDatos.close();
            
        } catch (SQLException ex) {
            Logger.getLogger(AccesoBDMySQL.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public Object [][] select(String strTabla, String strCampos, String strCondiciones, Connection conBD){
        
        Integer intRegistros = 0;      
        
        String strNombresColumnas[] = strCampos.split(",");

        //Consultas SQL
        String strSeleccion =
                "SELECT " + strCampos + 
                " FROM " + strTabla;
        
        String strSeleccionCont = 
                "SELECT COUNT(*) AS TOTAL" +
                " FROM " + strTabla;
        
        if ( strCondiciones != null) {
        
            strSeleccion  += " WHERE " + strCondiciones;
            strSeleccionCont += " WHERE " + strCondiciones;
        
        }
        
        try {
            
            PreparedStatement pstConsulta = conBD.prepareStatement(strSeleccionCont);
            ResultSet rstResultadoCont = pstConsulta.executeQuery();
            rstResultadoCont.next();
            intRegistros = rstResultadoCont.getInt("TOTAL");
            
        
        } catch(SQLException e){
        
            JOptionPane.showMessageDialog(null, e.getLocalizedMessage());
        
        }
    
        //se crea una matriz con tantas filas y columnas que necesite
        Object[][] data = new String[intRegistros][strCampos.split(",").length];
        
        //realizamos la consulta sql y llenamos los datos en la matriz "Object"
        try{
            
            PreparedStatement pstSeleccion = conBD.prepareStatement(strSeleccion);
            ResultSet rstResultado = pstSeleccion.executeQuery();
            
            Integer i = 0;
            
            while(rstResultado.next()){
            
                for (int j=0; j<= strCampos.split(",").length-1; j++) {
                    
                    data[i][j] = rstResultado.getString( strNombresColumnas[j].trim() );
                
                }
                
                i++;         
            
            }
            
            rstResultado.close();
            
        } catch(SQLException e){
        
            System.out.println(e);
        }
        return data;
    }
    
    public Object [][] selectOrdered(String strTabla, String strCampos, String strCondiciones, String strOrdenado, Connection conBD){
        
        Integer intRegistros = 0;      
        
        String strNombresColumnas[] = strCampos.split(",");

        //Consultas SQL
        String strSeleccion =
                "SELECT " + strCampos + 
                " FROM " + strTabla;
        
        String strSeleccionCont = 
                "SELECT COUNT(*) AS TOTAL " +
                " FROM " + strTabla;
        
        if ( strCondiciones != null) {        
            strSeleccion  += " WHERE " + strCondiciones;
            strSeleccionCont += " WHERE " + strCondiciones;        
        }
        
        if ( strOrdenado != null) {        
            strSeleccion  += " ORDER BY " + strOrdenado;                    
        }
        
        try {
            
            PreparedStatement pstConsulta = conBD.prepareStatement(strSeleccionCont);
            ResultSet rstResultadoCont = pstConsulta.executeQuery();
            rstResultadoCont.next();
            intRegistros = rstResultadoCont.getInt("TOTAL");
            
        
        } catch(SQLException e){
        
            JOptionPane.showMessageDialog(null, e.getLocalizedMessage());
        
        }
    
        //se crea una matriz con tantas filas y columnas que necesite
        Object[][] data = new String[intRegistros][strCampos.split(",").length];
        
        //realizamos la consulta sql y llenamos los datos en la matriz "Object"
        try{
            
            PreparedStatement pstSeleccion = conBD.prepareStatement(strSeleccion);
            ResultSet rstResultado = pstSeleccion.executeQuery();
            
            Integer i = 0;
            
            while(rstResultado.next()){
                for (int j=0; j<= strCampos.split(",").length-1; j++) {
                    data[i][j] = rstResultado.getString( strNombresColumnas[j].trim() );
                }                
                i++;
            }
            
            rstResultado.close();
            
        } catch(SQLException e){
        
            System.out.println(e);
        }
        return data;
    }
    
    //Obtener Preguntas
    public Object[][] obtenerPreguntas(Connection conBD){
        
        //Object[][] resQuestions = this.select("QUESTIONS", "NUMBER, QUESTION", null, conBD);
        Object[][] resQuestions = this.select("QUESTIONS", "NUMBER, QUESTION, IMAGES", null, conBD);
        
        if ( resQuestions.length > 0) {
        
            return resQuestions;
        
        } else {
        
            return null;
        
        }
    }
    
    //Obtener Preguntas 2
    public Object[][] obtenerPreguntas2(Connection conBD){
        
        //Para hacer pruebas
//        //Preguntas relacionadas con Installation, Configuration, etc...
//        String strCondiciones = "NUMBER IN (1,3,9,13,30,36,37,38,39,40,41,45)";
//        //Preguntas relacionadas con Network, DNS, DHCP, Firewall...
//        String strCondiciones = "NUMBER IN (11,18,19,20,21,32,43)";
//        //Preguntas relacionadas Hyper-V
//        String strCondiciones = "NUMBER IN (5,7,10,15,28)";
//        //Preguntas relacionadas con Active Directory
//        String strCondiciones = "NUMBER IN (6,12,14,17,22,24,25,26,27,42,47)";
//        //Preguntas relacionadas con Group Policies
//        String strCondiciones = "NUMBER IN (2,4,8,16,23,31,33,34,35,44,46,48)";   

//        //Preguntas de 1 a 100
//        String strCondiciones = "NUMBER >0 AND NUMBER < 101";
//        //Preguntas de 101 a 200
//        String strCondiciones = "NUMBER >100 AND NUMBER < 201";
//        //Preguntas de 201 a 300
//        String strCondiciones = "NUMBER >200 AND NUMBER < 301";
//        //Preguntas de 301 a 400
//        String strCondiciones = "NUMBER >300 AND NUMBER < 401";
        //Preguntas de 401 a 445
        String strCondiciones = "NUMBER >400 AND NUMBER < 500";
        
        //Object[][] resQuestions = this.select("QUESTIONS", "NUMBER, QUESTION", null, conBD);
        Object[][] resQuestions = this.select("QUESTIONS", "NUMBER, QUESTION, IMAGES", strCondiciones, conBD);
        
        if ( resQuestions.length > 0) {
        
            return resQuestions;
        
        } else {
        
            return null;
        
        }
    }
    
    //Obtener Preguntas 3
    public Object[][] obtenerPreguntas3(Connection conBD){
        
        //Para hacer pruebas
        String strCondiciones = "NUMBER > 24 AND NUMBER < 100";
        
        //Object[][] resQuestions = this.select("QUESTIONS", "NUMBER, QUESTION", null, conBD);
        Object[][] resQuestions = this.select("QUESTIONS", "NUMBER, QUESTION, IMAGES", strCondiciones, conBD);
        
        if ( resQuestions.length > 0) {
        
            return resQuestions;
        
        } else {
        
            return null;
        
        }
    }
    //Obtener Question Options
    public Object[][] obtenerOpcionesRespuesta(Connection conBD){
         
        Object[][] resOpcionesRespuesta = this.select("QUESTION_OPTIONS", "NUMBER, OPTION_NUMBER, OPTION_TEST, IS_VALID", null, conBD);
        
        if ( resOpcionesRespuesta.length > 0) {
        
            return resOpcionesRespuesta;
        
        } else {
        
            return null;
        
        }
    }
    
    //Obtener Opciones Respuesta filtrado por Número de Pregunta
    public Object[][] obtenerOpcionesRespuestaFiltradoPorNumeroDePregunta(Integer iNumero, Connection conBD){
         
        String strCondiciones = "NUMBER = " + iNumero;
        String strOrdenado = "OPTION_CHARACTER";
        
        Object[][] resQuestionOptions = this.selectOrdered("QUESTION_OPTIONS", "OPTION_CHARACTER, OPTION_TEXT", strCondiciones, strOrdenado, conBD);
        
        if ( resQuestionOptions.length > 0) {
        
            return resQuestionOptions;
        
        } else {
        
            return null;
       
        }
    }
    
    //Obtener Opciones Respuesta filtrado por Número de Pregunta 2
    public Object[][] obtenerOpcionesRespuestaFiltradoPorNumeroDePregunta2(Integer iNumero, Connection conBD){
         
        String strCondiciones = "NUMBER = " + iNumero;
        String strOrdenado = "OPTION_CHARACTER";
        
        Object[][] resQuestionOptions = this.selectOrdered("QUESTION_OPTIONS", "NUMBER, OPTION_NUMBER, OPTION_CHARACTER, OPTION_TEXT, IS_VALID", strCondiciones, strOrdenado, conBD);
        
        if ( resQuestionOptions.length > 0) {
        
            return resQuestionOptions;
        
        } else {
        
            return null;
        
        }
    }
    
    //Obtener Valores Respuesta filtrado por Número de Pregunta
    public Object[][] obtenerValoresRespuestaFiltradoPorNumeroDePregunta(Integer iNumero, Connection conBD){
         
        String strCondiciones = "NUMBER = " + iNumero;
        String strOrdenado = "OPTION_CHARACTER";
        
        Object[][] resQuestionOptions = this.selectOrdered("QUESTION_OPTIONS", "OPTION_NUMBER, OPTION_CHARACTER, IS_VALID", strCondiciones, strOrdenado, conBD);
        
        if ( resQuestionOptions.length > 0) {
        
            return resQuestionOptions;
        
        } else {
        
            return null;
        
        }
    }
         
    
}
